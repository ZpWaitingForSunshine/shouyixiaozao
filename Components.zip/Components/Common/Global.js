var Global = {
    "idtree":1
};
module.exports = Global;